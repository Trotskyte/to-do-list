import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { useState } from "react";
import { TaskProvider } from "./taskcontest.jsx"; // Import TaskProvider
import Navbar from "./navbar.jsx";
import Personal from "./personal.jsx";
import Completed from "./completed.jsx"; // Example

function App() {
  const [showSidebar, setShowSidebar] = useState(true); // Move sidebar state here

  function toggleSidebar() {
    setShowSidebar(!showSidebar);
  }

  return (
    <TaskProvider>
      <Router>
        <Navbar showSidebar={showSidebar} toggleSidebar={toggleSidebar} />
        <div className={`main-content ${showSidebar ? "" : "shift"}`}>
          <Routes>
            <Route path="/personal" element={<Personal showSidebar={showSidebar} />} />
            <Route path="/completed" element={<Completed />} />
          </Routes>
        </div>
      </Router>
    </TaskProvider>
  );
}

export default App;
