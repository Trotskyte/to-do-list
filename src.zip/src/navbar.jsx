import { Link } from "react-router-dom";

function Navbar({ showSidebar, toggleSidebar }) {
  return (
    <>
      <nav className="mobile-nav">
        <div className="menu-btn" onClick={toggleSidebar}>
          ☰ Menu
        </div>
      </nav>
      <div className={`sidebar ${showSidebar ? "show" : ""}`}>
        <img src="" alt="image-profile" />
        <h3>Rayyan Firmansyah</h3>
        <h1>TaskMate</h1>
        <p>To Do List App</p>
        <nav>
          <ul>
            <li>
              <Link to="/projects">Projects</Link>
              <Link to="/personal">Personal</Link>
              <Link to="/upcoming">Upcoming</Link>
              <Link to="/completed">Completed</Link>
            </li>
          </ul>
        </nav>
      </div>
    </>
  );
}

export default Navbar;
