function landing() {}
export default landing;
